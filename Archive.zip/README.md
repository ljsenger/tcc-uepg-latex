# tcc-uepg-latex
Este repositório contém os arquivos necessários para auxiliar os acadêmicos com a formatação de Trabalhos de Conclusão de Curso para a Universidade Estadual de Ponta Grossa, com o uso do sistema de compilação de textos LaTex e sistema de referências Bibtex. 
